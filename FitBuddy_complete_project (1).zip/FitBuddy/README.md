# FitBuddy – AI Fitness Plan Generator

This is a complete FastAPI prototype based on the supplied FitBuddy project specification.

## Features
- User form: name, user ID, age, weight, goal, intensity
- AI-generated 7-day workout plan
- Nutrition/recovery tip
- Feedback-based workout plan update
- SQLite + SQLAlchemy persistence
- Admin/coach dashboard
- Delete user function
- Jinja2 templates
- FastAPI `/docs`
- Gemini API integration
- Fallback plan/tip when no Gemini API key is configured

## Project structure

```text
FitBuddy/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── routes.py
│   ├── database.py
│   ├── schemas.py
│   ├── gemini_generator.py
│   └── gemini_flash_generator.py
├── templates/
│   ├── index.html
│   ├── result.html
│   └── all_users.html
├── static/
│   └── style.css
├── .env.example
├── requirements.txt
├── run.bat
├── run.sh
└── README.md
```

## Windows setup in VS Code

Open the FitBuddy folder in VS Code.

### 1. Create virtual environment

```powershell
python -m venv venv
```

### 2. Activate it

```powershell
venv\Scripts\activate
```

### 3. Install packages

```powershell
pip install -r requirements.txt
```

### 4. Configure Gemini

Copy `.env.example` to `.env` and put your Google Gemini API key in:

```env
GOOGLE_API_KEY=your_real_key_here
```

The prototype also runs without a key using fallback/demo generation.

### 5. Start the server

```powershell
uvicorn app.main:app --reload
```

### 6. Open

- App: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Admin dashboard: http://127.0.0.1:8000/view-all-users

## Important

The PDF specification describes Gemini 1.5 Pro and Gemini Flash and the `google-generativeai` package. This prototype keeps the same Gemini Pro/Flash roles but uses the current Google Gen AI Python SDK (`google-genai`) with configurable model names so the model can be changed in `.env` without editing the application code.

Fitness plans are general wellness content and are not medical advice.
