import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

API_KEY = os.getenv("GOOGLE_API_KEY")
MODEL = os.getenv("GEMINI_TIP_MODEL", "gemini-2.5-flash")


def generate_nutrition_tip_with_flash(goal):
    fallback = {
        "weight loss": "Prioritize protein and fiber-rich foods, stay hydrated, and choose portions that support your overall energy needs.",
        "muscle gain": "Include a protein source in each meal, such as eggs, chicken, fish, beans, or Greek yogurt, and support training with adequate overall nutrition.",
        "general wellness": "Build balanced meals around vegetables or fruit, a protein source, whole grains or other carbohydrates, and adequate water.",
        "flexibility": "Stay hydrated and include a balanced diet with protein and nutrient-rich foods to support recovery.",
    }

    if not API_KEY:
        return fallback.get(goal.lower(), fallback["general wellness"])

    try:
        client = genai.Client(api_key=API_KEY)
        prompt = f"""
Give one concise, practical nutrition or recovery tip for a person whose fitness goal is: {goal}.
Keep it under 100 words. Do not diagnose or treat medical conditions.
"""
        response = client.models.generate_content(model=MODEL, contents=prompt)
        return response.text
    except Exception:
        return fallback.get(goal.lower(), fallback["general wellness"])
