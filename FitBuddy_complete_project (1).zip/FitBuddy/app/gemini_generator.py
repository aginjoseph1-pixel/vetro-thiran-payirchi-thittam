import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

API_KEY = os.getenv("GOOGLE_API_KEY")
MODEL = os.getenv("GEMINI_WORKOUT_MODEL", "gemini-2.5-flash")


def _client():
    if not API_KEY:
        return None
    return genai.Client(api_key=API_KEY)


def _fallback_plan(username, age, weight, goal, intensity):
    return f"""7-DAY FITBUDDY WORKOUT PLAN
User: {username}
Age: {age}
Weight: {weight} kg
Goal: {goal}
Intensity: {intensity}

Day 1 - Full Body
Warm-up: 5-10 minutes brisk walking and mobility.
Main workout:
- Bodyweight squats: 3 x 12
- Incline push-ups: 3 x 10
- Glute bridges: 3 x 12
- Plank: 3 x 30 seconds
Cooldown: 5 minutes easy stretching.

Day 2 - Cardio
Warm-up: 5 minutes.
Main workout:
- Brisk walk/jog: 20-30 minutes
- Step-ups: 3 x 10 each leg
- Mountain climbers: 3 x 20
Cooldown: 5 minutes.

Day 3 - Recovery
Light walking for 20 minutes and gentle full-body mobility.

Day 4 - Upper Body + Core
Warm-up: 5-10 minutes.
Main workout:
- Push-ups or incline push-ups: 3 x 8-12
- Backpack rows: 3 x 12
- Shoulder taps: 3 x 16
- Dead bug: 3 x 10 each side
Cooldown: 5 minutes.

Day 5 - Lower Body
Warm-up: 5-10 minutes.
Main workout:
- Squats: 3 x 12
- Reverse lunges: 3 x 8 each leg
- Glute bridges: 3 x 15
- Calf raises: 3 x 15
Cooldown: 5 minutes.

Day 6 - Cardio + Mobility
20-30 minutes moderate cardio followed by 10 minutes mobility.

Day 7 - Rest
Rest, hydration, sleep, and gentle walking if comfortable.

Safety note: This is a prototype plan, not medical advice. Adjust or stop exercises if you experience pain or unusual symptoms."""


def generate_workout_gemini(username, age, weight, goal, intensity):
    prompt = f"""
You are FitBuddy, an AI fitness planning assistant.

Create a personalized 7-day workout plan for:
Name: {username}
Age: {age}
Weight: {weight} kg
Goal: {goal}
Preferred intensity: {intensity}

Requirements:
- Give exactly Day 1 through Day 7.
- Include warm-up, main workout, sets/reps or duration, rest guidance, and cooldown/recovery where appropriate.
- Tailor the plan to the stated goal and intensity.
- Keep it practical and easy to read.
- Do not claim to diagnose or treat medical conditions.
- If an exercise could be unsuitable for some people, mention a safer alternative.
"""

    client = _client()
    if not client:
        return _fallback_plan(username, age, weight, goal, intensity)

    try:
        response = client.models.generate_content(model=MODEL, contents=prompt)
        return response.text
    except Exception as exc:
        return _fallback_plan(username, age, weight, goal, intensity) + f"\n\n[Gemini temporarily unavailable: {type(exc).__name__}]"


def update_workout_plan(original_plan, feedback, goal, intensity):
    prompt = f"""
You are FitBuddy. Revise the following 7-day workout plan using the user's feedback.

Fitness goal: {goal}
Intensity: {intensity}

ORIGINAL PLAN:
{original_plan}

USER FEEDBACK:
{feedback}

Return a complete revised Day 1-Day 7 plan, not just a list of changes.
Keep the useful parts of the original plan while applying the feedback.
Include warm-up, workout details, rest/recovery, and cooldown where appropriate.
Avoid medical diagnosis or treatment claims.
"""

    client = _client()
    if not client:
        return original_plan + f"\n\nUPDATED BASED ON FEEDBACK:\n{feedback}"

    try:
        response = client.models.generate_content(model=MODEL, contents=prompt)
        return response.text
    except Exception:
        return original_plan + f"\n\nUPDATED BASED ON FEEDBACK:\n{feedback}"
