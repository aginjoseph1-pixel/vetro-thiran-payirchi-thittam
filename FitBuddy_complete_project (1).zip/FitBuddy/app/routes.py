from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import ValidationError

from app.schemas import UserInput, FeedbackRequest
from app.database import (
    save_user,
    save_plan,
    update_plan,
    get_user,
    get_all_users,
    delete_user,
)
from app.gemini_generator import generate_workout_gemini, update_workout_plan
from app.gemini_flash_generator import generate_nutrition_tip_with_flash

router = APIRouter()


def template_context(request: Request, **kwargs):
    return {"request": request, **kwargs}


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return request.app.state.templates.TemplateResponse(
        "index.html",
        template_context(request),
    )


@router.post("/generate-workout", response_class=HTMLResponse)
async def generate_workout(
    request: Request,
    username: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
):
    try:
        data = UserInput(
            username=username.strip(),
            user_id=user_id.strip(),
            age=age,
            weight=weight,
            goal=goal,
            intensity=intensity,
        )
    except ValidationError as exc:
        return request.app.state.templates.TemplateResponse(
            "index.html",
            template_context(request, error="Please enter valid details.", validation_errors=str(exc)),
            status_code=400,
        )

    user = save_user(
        data.user_id,
        data.username,
        data.age,
        data.weight,
        data.goal,
        data.intensity,
    )

    workout_plan = generate_workout_gemini(
        data.username, data.age, data.weight, data.goal, data.intensity
    )
    nutrition_tip = generate_nutrition_tip_with_flash(data.goal)
    save_plan(data.user_id, workout_plan, nutrition_tip)

    return request.app.state.templates.TemplateResponse(
        "result.html",
        template_context(
            request,
            user=user,
            workout_plan=workout_plan,
            nutrition_tip=nutrition_tip,
            message="Your personalized plan has been generated.",
        ),
    )


@router.post("/submit-feedback", response_class=HTMLResponse)
async def submit_feedback(
    request: Request,
    user_id: str = Form(...),
    feedback: str = Form(...),
):
    try:
        data = FeedbackRequest(user_id=user_id.strip(), feedback=feedback.strip())
    except ValidationError:
        return request.app.state.templates.TemplateResponse(
            "result.html",
            template_context(request, error="Please provide a valid feedback message."),
            status_code=400,
        )

    user = get_user(data.user_id)
    if not user:
        return request.app.state.templates.TemplateResponse(
            "result.html",
            template_context(request, error="User ID not found."),
            status_code=404,
        )

    updated = update_workout_plan(
        user.original_plan,
        data.feedback,
        user.goal,
        user.intensity,
    )
    update_plan(user.user_id, updated)
    user = get_user(user.user_id)

    return request.app.state.templates.TemplateResponse(
        "result.html",
        template_context(
            request,
            user=user,
            workout_plan=updated,
            nutrition_tip=user.nutrition_tip,
            message="Your workout plan was updated using your feedback.",
        ),
    )


@router.get("/view-all-users", response_class=HTMLResponse)
async def view_all_users(request: Request):
    users = get_all_users()
    return request.app.state.templates.TemplateResponse(
        "all_users.html",
        template_context(request, users=users),
    )


@router.post("/delete-user/{user_id}")
async def remove_user(user_id: str):
    delete_user(user_id)
    return RedirectResponse(url="/view-all-users", status_code=303)
